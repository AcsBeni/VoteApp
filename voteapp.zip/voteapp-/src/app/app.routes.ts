import { Routes } from '@angular/router';
import { PollsComponent } from './components/polls/polls.component';

export const routes: Routes = [
    {path:"", component:PollsComponent}
];
