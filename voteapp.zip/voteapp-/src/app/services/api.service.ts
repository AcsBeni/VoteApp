import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { }
  BaseUrl="http://localhost:3000"

  //Szavazás
  getPolls(){
    return this.http.get(`${this.BaseUrl}/polls`)
  }

  insertPolls(data:any){
    return this.http.post(`${this.BaseUrl}/polls`,data)
  }

  deletePolls(id:number){
    return this.http.delete(`${this.BaseUrl}/polls/${id}`)
  }

  //opciók
  getOptionsByPollId(poll_id:number){
    return this.http.get(`${this.BaseUrl}/polls/${poll_id}/options`)
  }

  insertOptions(data:any){
    return this.http.post(`${this.BaseUrl}/options`,data)
  }

  deleteOptions(id:number){
    return this.http.delete(`${this.BaseUrl}/options/${id}`)
  }
  //Szavazatok
  insertVotes(data:any){
    return this.http.post(`${this.BaseUrl}/votes`,data)
  }

  //statisztikák
  getStatsBypollId(poll_id:number){
    return this.http.get(`${this.BaseUrl}/polls/${poll_id}/stats`)
  }
}
