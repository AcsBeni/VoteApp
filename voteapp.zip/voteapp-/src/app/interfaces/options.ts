export interface Options {
    id?:number
    name:string
    poll_id:number
}
