export interface Votes {
    id?:number
    date?:Date
    option_id:number
}
