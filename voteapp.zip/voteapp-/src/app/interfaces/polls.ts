export interface Polls {
    id?:number
    title:string
    created_at?:Date
}
