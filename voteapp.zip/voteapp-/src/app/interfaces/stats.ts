export interface Stats {
    poll_id:number
    title:string
    option_id:string
    name:string
    vote_count:number
}
