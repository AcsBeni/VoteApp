import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Polls } from '../../interfaces/polls';
import { Options } from '../../interfaces/options';
import { Votes } from '../../interfaces/votes';
import { Stats } from '../../interfaces/stats';

@Component({
  selector: 'app-polls',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './polls.component.html',
  styleUrl: './polls.component.scss'
})
export class PollsComponent implements OnInit {

  constructor(private api:ApiService){}
  //Polls
  polls:Polls[]=[]
  newpoll:Polls={
    title: ''
  }
  //Options
  optionsOn=false;
  optiontitle='';
  pollId=0;
  options:Options[]=[]
  newOption:Options={
    name: '',
    poll_id: 0
  }
  //Votes
  votesOn = false
  Newvotes:Votes={
    option_id: 0
  }
  //stats
  Statistics:Stats[]=[]

  ngOnInit(): void {
    this.getPolls()
  }

  //SZAVAZÁS lekérdezések
  getPolls(){
    this.api.getPolls().subscribe({
      next:(res)=>{
        this.polls = res as Polls[]
      },
      error:(err)=>{
        console.log(err)
      }
    })
  }
  
  new(){
    this.newpoll.title = ''
  }
  save(){
    this.api.insertPolls(this.newpoll).subscribe({
      next:()=>{
        console.log("Sikeres hozzáadás")
      },
      error:(err)=>{
        console.log(err)
      }
    })
    this.getPolls()
  }
  delete(id:number){
    let conf = confirm("Biztosan szeretnéd törölni?")
    if(conf){
      this.api.deletePolls(id).subscribe({
      next:()=>{
        console.log("Sikeres törlés")
      },
      error:(err)=>{
        console.log(err)
      }
    })
    
    }
    this.getPolls()
  }
  //OPTIONS
  getOptions(poll:Polls){
    
    this.optionsOn = true
    this.optiontitle = poll.title
    this.newOption.poll_id = poll.id!
    this.pollId = poll.id!
    console.log(poll.id)
    this.api.getOptionsByPollId(poll.id!).subscribe({
      next:(res)=>{
        this.options = res as Options[]
      },
      error:(err)=>{
        console.log(err)
      }
    })
  }
  newOptions(){
    this.newOption.name=""
  }

  refreshOptions(id:number){
    this.pollId = id!
    this.newOption.id =id
    this.api.getOptionsByPollId(id!).subscribe({
      next:(res)=>{
        this.options = res as Options[]
      },
      error:(err)=>{
        console.log(err)
      }
    })
  }

  deleteOption(option:Options){
    let conf = confirm("Biztosan szeretnéd törölni?")
    if(conf){
      this.api.deletePolls(option.id!).subscribe({
      next:()=>{
        console.log("Sikeres törlés")
      },
      error:(err)=>{
        console.log(err)
      }
    })
    
    }
    this.refreshOptions(option.poll_id!)
  }
  saveOption(){
    this.api.insertOptions(this.newOption).subscribe({
       next:()=>{
        console.log("Sikeres hozzáadás")
      },
      error:(err)=>{
        console.log(err)
      }
    })
    this.refreshOptions(this.pollId)
  }


  //VOTES
  getVotes(option:Options){
    this.votesOn = true;
    
    
  }
  //Sats
  getStats(pollid:number){
    this.api.getStatsBypollId(pollid).subscribe({
      next:(res)=>{
        this.Statistics = res as Stats[]
        console.log(this.Statistics)
      },
      error:(err)=>{
        console.log(err)
      }
    })
  }

}
