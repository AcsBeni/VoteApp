var express = require("express")
var cors = require("cors")

var app= express()


app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(cors({
    origin:"http://localhost:4200"
}))
//modules
var polls = require("./modules/polls")
var options = require("./modules/options")
var votes = require("./modules/votes")

app.use("/polls", polls)
app.use("/options", options)
app.use("/votes", votes)

app.listen(3000, ()=>{
    console.log("app is listening on 3000") 
})