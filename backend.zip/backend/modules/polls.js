var express = require("express")
var router = express.Router()
var {query} = require("../utils/database")


//szavazások megszerzése
router.get("/", (req,res)=>{
    query("SELECT * from polls",[],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})
//szavazások létrehozása
router.post("/", (req,res)=>{
    let {title} = req.body
    if(!title){
        res.status(400).json("Hiányzó adatok")
    }
    query("INSERT INTO `polls`( `title`) VALUES (?)",[title],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})

//szavazás törlése id alapján
router.delete("/:id", (req,res)=>{
    let id = req.params.id
    query("DELETE from polls WHERE id=?",[id],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})
// OPTIONS --------------------

// szavazás opcióinak lekérdezése
router.get("/:id/options", (req,res)=>{
    let id = req.params.id
    query("SELECT * from options WHERE poll_id = ?",[id],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})

// STATS --------------------------

//szavazás eredményeinek lekérdezése
router.get("/:id/stats", (req,res)=>{
    let id = req.params.id
    query("SELECT * from poll_stats WHERE poll_id = ?",[id],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})

module.exports = router