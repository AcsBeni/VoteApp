var express = require("express")
var router = express.Router()
var {query} = require("../utils/database")


//szavazat rögzítése
router.post("/", (req,res)=>{
    let {option_id} = req.body
     if(!option_id){
        res.status(400).json("Hiányzó adatok")
    }
    query("INSERT INTO `votes`( `option_id`) VALUES (?)",[option_id],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})


module.exports = router