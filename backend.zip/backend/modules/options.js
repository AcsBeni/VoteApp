var express = require("express")
var router = express.Router()
var {query} = require("../utils/database")


//opció létrehozása
router.post("/", (req,res)=>{
    let {poll_id, name} = req.body
     if(!poll_id || !name){
        res.status(400).json("Hiányzó adatok")
    }
    query("INSERT INTO `options`( `poll_id`, `name`) VALUES (?,?)",[poll_id, name],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})

//poll törlése id alapján
router.delete("/:id", (req,res)=>{
    let id = req.params.id
    query("DELETE from options WHERE id=?",[id],(error,results)=>{
        if(error){
            return res.status(500).json({errno: error.message})
        }
        res.status(200).json(results)
    },req)
})


module.exports = router