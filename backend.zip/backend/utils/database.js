var mysql = require("mysql")

var pool = mysql.createPool({
    connectionLimit:10,
    database:"voteapp",
    user:"root",
    host:"localhost",
    password:""
})

function query(sql, params=[], callback){
    pool.query(sql, params, (error, results)=>{
        if(error){
            console.log(error)
        }
        if(callback){
            callback(error, results)
        }
    })
}

module.exports = {query}